using System.Text;
using System.Text.Json;
using RabbitMQ.Client;
namespace Common;
public record CalculationEvent(string Type,string Id,double Value);
public sealed class Bus : IDisposable {
 public const string Queue="valuator.processing.rank", Exchange="valuator.events";
 public readonly IConnection Connection;
 private readonly IModel publisher;
 private readonly object gate=new();
 public Bus() {
  var factory=new ConnectionFactory { HostName=Features.Env("MQ_HOST","localhost"),UserName=Features.Require("MQ_USER"),Password=Features.Require("MQ_PASSWORD"),DispatchConsumersAsync=true,AutomaticRecoveryEnabled=true };
  Connection=factory.CreateConnection(); publisher=CreateChannel(); publisher.ConfirmSelect();
 }
 public IModel CreateChannel() {
  var channel=Connection.CreateModel();
  channel.QueueDeclare(Queue,true,false,false,null);
  channel.ExchangeDeclare(Exchange,ExchangeType.Fanout,true,false,null);
  return channel;
 }
 public void Rank(string id)=>Publish("",Queue,id);
 public void Event(CalculationEvent ev)=>Publish(Exchange,"",JsonSerializer.Serialize(ev));
 private void Publish(string exchange,string key,string body) {
  lock(gate) {
   var properties=publisher.CreateBasicProperties();properties.Persistent=true;
   publisher.BasicPublish(exchange,key,properties,Encoding.UTF8.GetBytes(body));
   publisher.WaitForConfirmsOrDie(TimeSpan.FromSeconds(10));
  }
 }
 public void Dispose(){publisher.Dispose();Connection.Dispose();}
}
