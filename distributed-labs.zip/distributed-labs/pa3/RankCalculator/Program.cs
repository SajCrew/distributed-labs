using Common;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text;
using var store=new Store();using var bus=new Bus();using var ch=bus.CreateChannel();
using var cts=new CancellationTokenSource();
Console.CancelKeyPress+=(_,e)=>{e.Cancel=true;cts.Cancel();};
System.Runtime.Loader.AssemblyLoadContext.Default.Unloading+=_=>cts.Cancel();
ch.BasicQos(0,1,false);
var consumer=new AsyncEventingBasicConsumer(ch);
consumer.Received+=async(_,ea)=>{
 try {
  string id=Encoding.UTF8.GetString(ea.Body.Span);
  var data=await store.Read(id)??throw new InvalidOperationException("Text not found");
  if(Features.Live && data.Rank==null)await Task.Delay(TimeSpan.FromSeconds(Random.Shared.Next(3,16)),cts.Token);
  double rank=data.Rank??Metrics.Rank(data.Text);
  await store.SaveRank(id,rank);
  if(Features.Events)bus.Event(new("RankCalculated",id,rank));
  ch.BasicAck(ea.DeliveryTag,false);
  Console.WriteLine($"RankCalculated {id} {rank} worker={Environment.MachineName}");
 }catch(OperationCanceledException){}catch(Exception ex){Console.Error.WriteLine(ex);await Task.Delay(1000);ch.BasicNack(ea.DeliveryTag,false,true);}
};
ch.BasicConsume(Bus.Queue,false,consumer);
try{await Task.Delay(Timeout.Infinite,cts.Token);}catch(OperationCanceledException){}
