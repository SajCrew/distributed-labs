#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
command -v docker >/dev/null 2>&1 || { echo "Install Docker with Compose." >&2; exit 1; }
docker info >/dev/null 2>&1 || { echo "Start Docker and try again." >&2; exit 1; }
if [ ! -f .env ]; then
    cp .env.example .env
    echo "Created .env. Edit STUDENT_NAME and STUDENT_GROUP."
fi
docker compose config --quiet
if ! docker compose up -d --build --wait --wait-timeout 180; then
    docker compose ps -a
    docker compose logs --tail 60
    exit 1
fi
# Check PA1 from inside the same Compose network; do not depend on host curl.
if ! docker compose run --rm --no-deps --entrypoint sh redis -c '
    i=0
    while [ "$i" -lt 30 ]; do
        if wget -q -O /dev/null http://web1:5001/health; then exit 0; fi
        i=$((i + 1))
        sleep 2
    done
    exit 1
'; then
    docker compose logs --tail 60
    exit 1
fi
docker compose ps -a
echo "Ready: http://localhost:5001"
