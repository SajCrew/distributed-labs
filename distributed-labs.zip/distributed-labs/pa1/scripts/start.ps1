$ErrorActionPreference = "Stop"
Push-Location (Join-Path $PSScriptRoot "..")
try {
    if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
        throw "Docker was not found. Install and start Docker Desktop (Linux containers)."
    }
    & docker info *> $null
    if ($LASTEXITCODE -ne 0) { throw "Docker Desktop is not ready. Start it and try again." }
    if (-not (Test-Path -LiteralPath '.env' -PathType Leaf)) {
        Copy-Item -LiteralPath '.env.example' -Destination '.env'
        Write-Host "Created .env. Edit STUDENT_NAME and STUDENT_GROUP for the About page."
    }
    & docker compose config --quiet
    if ($LASTEXITCODE -ne 0) { throw "Invalid compose.yaml or .env." }
    & docker compose up -d --build --wait --wait-timeout 180
    if ($LASTEXITCODE -ne 0) { throw "Build/start failed. See the error above and logs below." }
    $url = 'http://localhost:5001'
    $ready = $false
    for ($attempt = 0; $attempt -lt 30; $attempt++) {
        try {
            $response = Invoke-WebRequest -UseBasicParsing -Uri "$url/health" -TimeoutSec 3
            if ($response.StatusCode -eq 200) { $ready = $true; break }
        } catch { }
        Start-Sleep -Seconds 2
    }
    if (-not $ready) { throw "The application did not respond at $url/health." }
    & docker compose ps -a
    Write-Host "Ready: $url" -ForegroundColor Green
    Write-Host "Keep Docker Desktop running. stop.cmd stops this laboratory."
    try { Start-Process $url } catch { Write-Host "Open $url in your browser." }
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    if (Get-Command docker -ErrorAction SilentlyContinue) {
        & docker compose ps -a
        & docker compose logs --tail 60
    }
    exit 1
} finally {
    Pop-Location
}
