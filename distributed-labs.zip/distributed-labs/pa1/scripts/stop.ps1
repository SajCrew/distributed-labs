$ErrorActionPreference = "Stop"
Push-Location (Join-Path $PSScriptRoot "..")
try {
    & docker compose down
    if ($LASTEXITCODE -ne 0) { throw "Failed to stop the laboratory." }
    Write-Host "Stopped. Saved data is preserved."
} catch {
    Write-Host $_.Exception.Message -ForegroundColor Red
    exit 1
} finally {
    Pop-Location
}
