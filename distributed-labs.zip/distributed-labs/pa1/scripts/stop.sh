#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
docker compose down
echo "Stopped. Saved data is preserved."
