@echo off
setlocal
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\start.ps1"
set "LAB_EXIT_CODE=%ERRORLEVEL%"
if not "%LAB_EXIT_CODE%"=="0" echo Operation failed. See the messages above.
pause
exit /b %LAB_EXIT_CODE%
