using Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Identity;
using StackExchange.Redis;
using System.Security.Claims;
namespace Valuator.Pages;
public class LoginModel(Store store):PageModel {
 public IActionResult OnGet()=>Features.Auth?Page():NotFound();
 public async Task<IActionResult> OnPostAsync(string? login,string? password,string action) {
  if(!Features.Auth)return NotFound();
  login=login?.Trim().ToLowerInvariant();
  if(string.IsNullOrEmpty(login)||login.Length>100||string.IsNullOrEmpty(password)||password.Length<8||password.Length>256){ModelState.AddModelError("","Логин: 1–100 символов. Пароль: 8–256 символов.");return Page();}
  string key="USER-"+login;
  var hasher=new PasswordHasher<string>();
  if(action=="register") {
   var hash=hasher.HashPassword(login,password);
   if(!await store.Db().StringSetAsync(key,hash,when:When.NotExists)){ModelState.AddModelError("","Логин уже занят.");return Page();}
  }else {
   var hash=await store.Db().StringGetAsync(key);
   if(hash.IsNull||hasher.VerifyHashedPassword(login,hash.ToString(),password)==PasswordVerificationResult.Failed){ModelState.AddModelError("","Неверный логин или пароль.");return Page();}
  }
  var identity=new ClaimsIdentity(new[]{new Claim(ClaimTypes.Name,login)},CookieAuthenticationDefaults.AuthenticationScheme);
  await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,new ClaimsPrincipal(identity));
  return RedirectToPage("/Index");
 }
}
public class LogoutModel:PageModel {
 public async Task<IActionResult> OnPostAsync(){await HttpContext.SignOutAsync();return RedirectToPage("/Index");}
}
