using Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace Valuator.Pages;
public class IndexModel(Store store,IServiceProvider services):PageModel {
 public IActionResult OnGet()=>Features.Auth && User.Identity?.IsAuthenticated!=true ? Challenge() : Page();
 public async Task<IActionResult> OnPostAsync(string? text,string country="Russia") {
  if(Features.Auth && User.Identity?.IsAuthenticated!=true)return Challenge();
  if(string.IsNullOrWhiteSpace(text)||text.Length>100000){ModelState.AddModelError("","Введите текст длиной от 1 до 100000 символов.");return Page();}
  if(Features.Shards && !Features.Countries.ContainsKey(country))return BadRequest();
  var id=await store.Create(text,country,User.Identity?.Name??"");
  var result=await store.Read(id) ?? throw new InvalidOperationException();
  if(Features.AsyncRank) {
   var bus=services.GetRequiredService<Bus>();
   if(Features.Events)bus.Event(new("SimilarityCalculated",id,result.Similarity));
   bus.Rank(id);
  }else await store.SaveRank(id,Metrics.Rank(text));
  return Redirect($"/Summary?id={id}");
 }
}
