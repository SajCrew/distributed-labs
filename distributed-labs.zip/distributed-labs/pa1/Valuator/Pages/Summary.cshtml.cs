using Common;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
namespace Valuator.Pages;
public class SummaryModel(Store store):PageModel {
 public Result Data {get;private set;}=null!;
 public async Task<IActionResult> OnGetAsync(string? id) {
  if(Features.Auth && User.Identity?.IsAuthenticated!=true)return Challenge();
  if(!Guid.TryParse(id,out _))return BadRequest();
  var result=await store.Read(id!);if(result==null)return NotFound();
  if(Features.Auth && result.Owner!=User.Identity?.Name)return StatusCode(403);
  Data=result;return Page();
 }
}
