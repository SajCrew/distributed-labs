using Common;
using Microsoft.AspNetCore.SignalR;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text.Json;
namespace Valuator;
public class ResultsHub(Store store):Hub {
 public async Task Watch(string id) {
  if(!Guid.TryParse(id,out _))throw new HubException("Invalid ID");
  var result=await store.Read(id)??throw new HubException("Not found");
  if(Features.Auth && result.Owner!=Context.User?.Identity?.Name)throw new HubException("Forbidden");
  await Groups.AddToGroupAsync(Context.ConnectionId,id);
  // Read after joining: an event between page rendering and subscribing cannot be lost.
  result=await store.Read(id);
  await Clients.Caller.SendAsync("Snapshot",result);
 }
}
public class EventBridge(Bus bus,IHubContext<ResultsHub> hub):BackgroundService {
 protected override async Task ExecuteAsync(CancellationToken ct) {
  using var ch=bus.CreateChannel();
  var queue=ch.QueueDeclare("",false,true,true,null).QueueName;
  ch.QueueBind(queue,Bus.Exchange,"");
  var consumer=new AsyncEventingBasicConsumer(ch);
  consumer.Received+=async(_,ea)=>{
   var ev=JsonSerializer.Deserialize<CalculationEvent>(ea.Body.Span)!;
   await hub.Clients.Group(ev.Id).SendAsync(ev.Type,ev,ct);
   ch.BasicAck(ea.DeliveryTag,false);
  };
  ch.BasicConsume(queue,false,consumer);
  await Task.Delay(Timeout.Infinite,ct);
 }
}
