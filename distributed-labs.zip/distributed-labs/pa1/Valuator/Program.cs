using Common;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.DataProtection;
using Valuator;
var builder=WebApplication.CreateBuilder(args);
builder.Services.AddRazorPages();
builder.Services.AddSingleton<Store>();
if(Features.AsyncRank) builder.Services.AddSingleton<Bus>();
builder.Services.AddDataProtection().PersistKeysToFileSystem(new DirectoryInfo(Features.Env("KEYS_PATH",".keys"))).SetApplicationName("Valuator");
builder.Services.AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme).AddCookie(o=>{o.LoginPath="/Login";o.AccessDeniedPath="/Login";o.Cookie.HttpOnly=true;o.Cookie.SameSite=SameSiteMode.Lax;});
builder.Services.AddAuthorization();
if(Features.Live){builder.Services.AddSignalR();builder.Services.AddHostedService<EventBridge>();}
var app=builder.Build();
app.UseStaticFiles();app.UseRouting();app.UseAuthentication();app.UseAuthorization();
app.Use(async(ctx,next)=>{ctx.Response.Headers["X-Instance"]=Environment.MachineName;await next();});
app.MapGet("/health",()=>Results.Ok(new{status="ok",lab=Features.Lab}));
app.MapRazorPages();
if(Features.Live)app.MapHub<ResultsHub>("/results");
app.Run();
