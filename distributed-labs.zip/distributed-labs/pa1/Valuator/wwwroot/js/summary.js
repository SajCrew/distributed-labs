(async () => {
 const id=document.getElementById('text-id').textContent.trim();
 const status=document.getElementById('connection-status');
 const connection=new signalR.HubConnectionBuilder().withUrl('/results',{transport:signalR.HttpTransportType.WebSockets,skipNegotiation:true}).withAutomaticReconnect().build();
 const rank=value=>{if(value!==null)document.getElementById('rank').textContent=value;};
 connection.on('RankCalculated',e=>rank(e.value));
 connection.on('SimilarityCalculated',e=>document.getElementById('similarity').textContent=e.value);
 connection.on('Snapshot',s=>{rank(s.rank);document.getElementById('similarity').textContent=s.similarity;});
 async function watch(){await connection.invoke('Watch',id);status.textContent='Обновления подключены';}
 connection.onreconnected(watch);
 connection.onreconnecting(()=>status.textContent='Восстановление соединения…');
 async function start(){try{await connection.start();await watch();}catch(e){status.textContent='Нет соединения, повтор через 3 секунды';setTimeout(start,3000);}}
 connection.onclose(start);await start();
})();
