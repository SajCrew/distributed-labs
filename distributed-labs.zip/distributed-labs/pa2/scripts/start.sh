#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/.."
command -v docker >/dev/null 2>&1 || { echo "Install Docker with Compose." >&2; exit 1; }
docker info >/dev/null 2>&1 || { echo "Start Docker and try again." >&2; exit 1; }
if [ ! -f .env ]; then
    cp .env.example .env
    echo "Created .env. Edit STUDENT_NAME and STUDENT_GROUP."
fi
docker compose config --quiet
if ! docker compose up -d --build --wait --wait-timeout 180; then
    docker compose ps -a
    docker compose logs --tail 60
    exit 1
fi
docker compose ps -a
echo "Ready: http://localhost:8080"
