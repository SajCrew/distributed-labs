using System.Globalization;
using System.Security.Cryptography;
using System.Text;
using StackExchange.Redis;
namespace Common;
public static class Features {
 public const int Lab = 4;
 public static bool AsyncRank => Lab >= 3;
 public static bool Events => Lab >= 4;
 public static bool Live => Lab == 5;
 public static bool Shards => Lab == 6;
 public static bool Auth => Lab == 7;
 public static string Env(string key, string fallback) => Environment.GetEnvironmentVariable(key) ?? fallback;
 public static string Require(string key) => Environment.GetEnvironmentVariable(key) ?? throw new InvalidOperationException("Set environment variable " + key);
 public static readonly Dictionary<string,string> Countries = new() {{"Russia","RU"},{"France","EU"},{"Germany","EU"},{"UAE","ASIA"},{"India","ASIA"}};
}
public static class Metrics {
 public static double Rank(string text) {
  var chars = text.EnumerateRunes().ToArray();
  if(chars.Length == 0) return 0;
  return (double)chars.Count(r => !(r.Value is >= 'a' and <= 'z' or >= 'A' and <= 'Z' or >= 'а' and <= 'я' or >= 'А' and <= 'Я' or 'ё' or 'Ё')) / chars.Length;
 }
}
public record Result(string Id,string Text,double? Rank,int Similarity,string Owner);
public sealed class Store : IDisposable {
 private readonly Dictionary<string,ConnectionMultiplexer> connections = new();
 private readonly object gate = new();
 public IDatabase Db(string region="MAIN") {
  lock(gate) {
   if(!connections.TryGetValue(region,out var connection)) {
    var config=ConfigurationOptions.Parse(Features.Env("DB_"+region,"localhost:6379"));
    config.Password=Features.Auth ? Features.Require("REDIS_PASSWORD") : Environment.GetEnvironmentVariable("REDIS_PASSWORD");
    config.AbortOnConnectFail=false;
    connection=ConnectionMultiplexer.Connect(config); connections[region]=connection;
   }
   return connection.GetDatabase();
  }
 }
 public async Task<IDatabase?> Lookup(string id) {
  if(!Features.Shards) return Db();
  var region=await Db().StringGetAsync("SHARD-"+id);
  if(region.IsNull) return null;
  Console.WriteLine($"LOOKUP: {id}, {region}");
  return Db(region.ToString());
 }
 public async Task<string> Create(string text,string country,string owner) {
  string id=Guid.NewGuid().ToString();
  string region=Features.Shards ? Features.Countries[country] : "MAIN";
  var db=Db(region);
  string hash=Convert.ToHexString(SHA256.HashData(Encoding.UTF8.GetBytes(text)));
  // Acquire locks in the same order on all shards: duplicate detection is global.
  var databases=(Features.Shards ? new[]{"ASIA","EU","RU"} : new[]{"MAIN"}).Select(Db).ToArray();
  string token=Guid.NewGuid().ToString();
  var locked=new List<IDatabase>();
  try {
   foreach(var d in databases) {
    var deadline=DateTime.UtcNow.AddSeconds(20);
    while(!await d.LockTakeAsync("DEDUP-LOCK",token,TimeSpan.FromSeconds(60))) {
     if(DateTime.UtcNow>deadline) throw new TimeoutException("Duplicate index is busy");
     await Task.Delay(50);
    }
    locked.Add(d);
   }
   bool duplicate=false;
   foreach(var d in databases) duplicate |= await d.KeyExistsAsync("HASH-"+hash);
   await db.StringSetAsync(new KeyValuePair<RedisKey,RedisValue>[] {
    new("TEXT-"+id,text),new("SIMILARITY-"+id,duplicate?1:0),new("OWNER-"+id,owner),new("HASH-"+hash,id)
   });
   if(Features.Shards) await Db().StringSetAsync("SHARD-"+id,region);
  } finally { foreach(var d in locked.AsEnumerable().Reverse()) await d.LockReleaseAsync("DEDUP-LOCK",token); }
  return id;
 }
 public async Task<Result?> Read(string id) {
  var db=await Lookup(id); if(db==null) return null;
  var v=await db.StringGetAsync(new RedisKey[]{"TEXT-"+id,"RANK-"+id,"SIMILARITY-"+id,"OWNER-"+id});
  if(v[0].IsNull) return null;
  return new(id,v[0].ToString(),v[1].IsNull?null:double.Parse(v[1].ToString(),CultureInfo.InvariantCulture),(int)v[2],v[3].ToString());
 }
 public async Task SaveRank(string id,double rank) {
  var db=await Lookup(id) ?? throw new InvalidOperationException("Unknown text");
  await db.StringSetAsync("RANK-"+id,rank.ToString("R",CultureInfo.InvariantCulture));
 }
 public void Dispose() {foreach(var c in connections.Values)c.Dispose();}
}
