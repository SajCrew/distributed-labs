using Common;
using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text.Json;
using var bus=new Bus();using var ch=bus.CreateChannel();
using var cts=new CancellationTokenSource();
Console.CancelKeyPress+=(_,e)=>{e.Cancel=true;cts.Cancel();};
System.Runtime.Loader.AssemblyLoadContext.Default.Unloading+=_=>cts.Cancel();
// Each instance has its own queue: both receive every event while connected.
var queue=ch.QueueDeclare("",false,true,true,null).QueueName;
ch.QueueBind(queue,Bus.Exchange,"");
var consumer=new AsyncEventingBasicConsumer(ch);
consumer.Received+=(_,ea)=>{
 var ev=JsonSerializer.Deserialize<CalculationEvent>(ea.Body.Span)!;
 Console.WriteLine($"{ev.Type}: ID={ev.Id}, value={ev.Value}, logger={Environment.MachineName}");
 ch.BasicAck(ea.DeliveryTag,false);return Task.CompletedTask;
};
ch.BasicConsume(queue,false,consumer);
try{await Task.Delay(Timeout.Infinite,cts.Token);}catch(OperationCanceledException){}
